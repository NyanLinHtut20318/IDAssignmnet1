This is for recruiters or employers and it is to introduce Ken and as well as show them my qualifications and provide them with my contacts so that they can call me.
Recruiters and employers will know me better so that they can decide whether to hire me or not.
The website is for helping me to introduce myself to future employers in the best light.
https://bleedingcool.com/wp-content/uploads/2017/06/Man-Bun-ken-2.jpg
https://i.ytimg.com/vi/Tuz4K2O9u5U/maxresdefault.jpg
https://i.pinimg.com/originals/70/b7/e6/70b7e6d9197edcb6662b3bc51e0543ff.png

